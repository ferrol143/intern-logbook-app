export interface Activity {
  id: string
  tanggal: string
  jenisKegiatan: string
  waktuMulai: string
  waktuSelesai: string
  tipePekerjaan: string
  lokasiKegiatan: string
  keteranganKegiatan: string
  buktiKegiatan: string
}